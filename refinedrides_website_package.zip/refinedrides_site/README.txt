
REFINED RIDES WEBSITE

Files included:
- index.html
- assets/gtr.jpeg
- assets/logo.jpeg

To launch:
1. Upload the contents to your hosting provider connected to refinedrides.website
2. Set index.html as the homepage
3. Optional: connect a form service like Formspree for live booking submissions

Business info included:
- Nashville local detailing
- Phone: 615-540-7761
- Email: AMdetailzzzz@gmail.com
